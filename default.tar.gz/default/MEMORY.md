# Memory Lintas Sesi

## Fakta tetap
- Stack dibangun 25 Agustus 2026
- 9Router v0.4.66 di port 20128
- Ollama di port 11434

## Keputusan yang sudah dibuat
- Model utama: groq/llama-3.3-70b-versatile
- Hindari cf/* untuk task panjang
- Semua service dikunci ke 127.0.0.1

## Hal yang sedang dipelajari
- Integrasi Hermes + 9Router + Caveman + Obsidian

## Jangan dilakukan
- Jangan restart 9Router tanpa konfirmasi

## Keputusan proyek BEM (25 Aug 2026)
- MariaDB/MySQL = engine utama; PostgreSQL sekunder DIPERTAHANKAN; SQLite tidak dipakai.
- Live DB bem_astawidya tidak boleh diubah tanpa approval — hanya referensi dump.
- Parser .env config/database.php FIRST-WINS — jangan duplikasi key.
- Tabel deprecated (keterangan_master, penanggung_jawab_master, signatures) dipertahankan bermarker.
- Konversi MyISAM→InnoDB hanya sebagai hardening opsional dengan approval.
