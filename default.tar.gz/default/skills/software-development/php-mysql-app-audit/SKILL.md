---
name: php-mysql-app-audit
description: Use when auditing legacy PHP+MySQL apps for schema drift.
---

# Auditing / remediating a legacy PHP + MySQL/MariaDB app

Covers repo-vs-database audits, `.env` parsing bugs, doc alignment, and remediation of "no such table/column" errors in PHP webapps.

## Gated workflow (user-mandated pattern)

Bufan's projects use explicit approval gates. Follow this sequence:

1. **STEP A — audit only**: inventory repo structure, config, schemas, logs. Change NOTHING.
2. **STEP B — determine engine source of truth from evidence** (docker-compose, Dockerfile, .env.example, composer.json ext-*), never assumptions.
3. **STEP C — diff three layers**: code-required tables/columns (grep FROM/JOIN/INSERT INTO/UPDATE) vs live DB (`SHOW CREATE TABLE` / `mariadb-dump`) vs checked-in schema files.
4. **GATE — deliver full report, then STOP with `WAITING FOR USER APPROVAL`**. No edits until explicit approval. The user often replies "approved WITH REVISIONS" — apply revisions verbatim (they commonly forbid deleting unreferenced tables, forbid storage-engine conversions, require backups).
5. Execute in approved order; re-stop if a NEW architecture decision surfaces mid-execution.
6. After code changes: `php -l` all touched files, `composer validate`, then HTTP smoke-test every public page plus admin/API endpoints expecting 302/401 (auth gates).

## Pitfalls

- **Duplicate `.env` keys**: dotenv-style loaders using `if (!isset($_ENV[$key]))` are FIRST-wins, but many tools are LAST-wins — an orphan trailing line like `DB_DATABASE=database/database.sqlite` can silently override the real value. Always grep `.env` for duplicate keys during audits.
- **FPM cannot read user-owned files**: `.env` chmod 600/640 owned by the dev user is invisible to php-fpm running as `www-data` → app gets EMPTY creds → "Access denied for user ''@'localhost'". CLI works fine, so the bug hides. Fix: chgrp to web-server group (needs root) or chmod 644 as fallback; verify by curling pages AFTER the fix, not by CLI tests.
- **Never ship a hand-written bcrypt hash in docs** — generate it (`php -r "echo password_hash('pw', PASSWORD_DEFAULT);"`) and `password_verify()` it back BEFORE writing into any document. Fabricated hashes silently fail on fresh installs.
- **Partial/include-only PHP files 500 on direct URL access** (undefined functions from parent context) — that's expected, not a bug. Auth-gated admin routes may return app-level 404 deliberately (session guard before any output). Classify before flagging.
- **`git status` noise**: pre-existing uncommitted diffs may be huge; check whether YOUR change is in the diff before assuming you caused it.
- **Removing seed data is a behavior change**: if you strip INSERT statements while regenerating a schema, fresh installs have zero users — document a verified first-admin bootstrap procedure in INSTALL docs.
- **Duplicated doc files** (same guide at two paths): diff before overwriting one from the other; merge unique sections first, then sync both copies.
- **Docs drift to check**: README PHP version badge vs composer.json `php` requirement; referenced-but-nonexistent template files (`.env.example.mysql` etc.); env var naming mismatches between docs and code (`DB_SSL_MODE` vs `DB_SSLMODE`).

## Schema regeneration recipe

```bash
cp databases/schema_mysql.sql databases/schema_mysql.sql.bak-YYYY-MM-DD   # backup FIRST
mariadb-dump -u USER -pPW --no-data --skip-comments DB_NAME > /tmp/raw.sql
```
Then post-process: strip sandbox-mode/DEFINER lines, drop `AUTO_INCREMENT=<n>` counters, unwrap `/*!50001 ... */` conditional comments around views into plain `CREATE OR REPLACE VIEW`, keep MyISAM/latin1 tables AS-IS unless explicitly approved to convert. Re-add deprecated-but-kept tables from the backup with a deprecation comment block. Validate statically (balanced statements, view sources exist as tables) — importing needs CREATE privileges you may not have; say so instead of claiming tested-import.