# BEM Astawidya audit — worked example (2026-08-25)

Concrete application of the php-mysql-app-audit workflow to /var/www/html/bem (BEM Organization System, PHP 8.5 + MariaDB 11.8 native local, mariadb:10.11 container production).

## Root causes found

1. **`.env` had two `DB_DATABASE` lines** — correct `bem_astawidya` first, orphan trailing `DB_DATABASE=database/database.sqlite`. The app's dotenv loader is FIRST-wins (`if (!isset($_ENV[$key]))`) so the app actually used the right DB name, but the conflict produced contradictory logs and confusion; earlier php-error.log entries showed MySQL syntax run against SQLite.
2. **`databases/schema_mysql.sql` was ~2 feature-generations stale** vs live DB: 10 tables missing entirely (surat_templates, lampiran_pinjam, rundown_tempat/pj/keterangan, arsip_panitia, arsip_teks_mc, visi_misi, panitia_tetap, kontak); many columns missing (kegiatan.waktu_pelaksanaan/tempat_pelaksanaan/kode_kegiatan/..., arsip_surat.kegiatan_id/status_arsip/status_humas, notifikasi.judul, users.file_ttd/google_*/totp_*, anggota_*.user_id). Runtime auto-migration in includes/functions.php had been silently patching gaps with try-SELECT→ALTER + empty catch blocks.
3. **`config/database.php` `$dbSslMode` bug**: value stored in a local var at load time but read from `$GLOBALS['dbSslMode']` in getConnection() → pgsql sslmode never applied. Fixed by writing `$GLOBALS['dbSslMode'] = $dbSslMode;` when set.
4. **Docs drift**: README badge said PHP 7.4+ (composer requires >=8.1); INSTALL referenced nonexistent `.env.example.mysql`/`.env.example.pgsql`; docs said `DB_SSL_MODE`, code reads `DB_SSLMODE`; plaintext-password seed comment in old schema; same guide duplicated at two doc paths with diverging content.

## User's GATE revisions (pattern worth remembering)

- Do NOT delete keterangan_master / penanggung_jawab_master / signatures before verifying zero dependencies → kept in schema with deprecation comment block instead.
- Do NOT convert MyISAM/latin1→InnoDB/utf8mb4 as part of remediation → schema must mirror live DB exactly; engine hardening deferred as separate optional task.
- Verify Laravel-scaffold env vars truly unused before removing (grep APP_/SESSION_/CACHE_/REDIS_ across code → 0 refs → removed).
- PostgreSQL still actively supported (28 pgsql refs in 6 files) → composer.json got `ext-pdo_mysql` ADDED beside ext-pdo_pgsql, not replacing it.
- Live DB read-only reference; regenerate schema with --no-data only.
- Backup old schema file first (schema_mysql.sql.bak-2026-08-25).

## Execution notes

- mariadb-dump --no-data output needed cleanup: sandbox-mode line, DEFINER clauses, AUTO_INCREMENT counters, /*!50001 */ conditional comments around views → rewritten to plain CREATE OR REPLACE VIEW.
- No CREATE privilege on server → could NOT test-import into throwaway DB (no docker either). Did static validation only: statement balance, view sources ⊆ tables. Reported honestly as "not import-tested".
- Old schema's superadmin seed INSERT had a FAKE bcrypt hash (documented password admin1234 never worked from fresh import anyway). New schema is structure-only; INSTALL.md now documents bootstrap with a REAL generated hash (password_verify-checked) plus the one-liner to regenerate.
- Validation results: php -l clean on all app PHP; composer validate OK; nginx smoke test — all 9 public pages 200, admin/ 302→login, api/notifications.php 401 (auth gate), footer.php 500 direct-access expected (include-only partial calling assetUrl()).
- Fresh error discovered during smoke test: `.env` was chmod 640 bufan:bufan → php-fpm (www-data) couldn't read → "Access denied for user ''@'localhost'". CLI tests all passed while web failed. chmod 644 fixed it (chown bufan:www-data preferred but needs root).
