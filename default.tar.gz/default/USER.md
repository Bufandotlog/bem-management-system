# Profil Bufan

## Identitas
- Nama: bufan
- Lokasi: Cirebon, Indonesia
- Perangkat: Linux Ubuntu, Brave browser, Antigravity IDE
- Shell: zsh

## Proyek aktif
- BEM Astawidya: sistem manajemen organisasi di /var/www/html/bem (PHP 8.1 + MariaDB, nginx+php8.5-fpm). Live DB bem_astawidya = source of truth schema. scratch/bem_lpj_manager.py = engine LPJ aktif, jangan dihapus.
- Stack AI: Hermes + 9Router + Caveman + Obsidian
- Vault path: ~/Documents/bufandotlog
- Endpoint 9Router: http://localhost:20128/v1
- Combo model: hermes_mainchar
- Fallback chain: Groq → OpenRouter → Ollama lokal (qwen2.5:7b)

## Preferensi komunikasi
- Bahasa: Indonesia
- Gaya: langsung, tidak verbose, sistematis

## Konteks teknis
- 9Router: systemd service, auto-start, port 20128
- Ollama: qwen2.5:7b di 127.0.0.1:11434
- Semua port dikunci ke 127.0.0.1

## Pantangan
- Jangan buka port ke publik tanpa konfirmasi eksplisit
- Jangan hapus file tanpa konfirmasi
- Hindari model cf/* untuk task panjang (context limit 24k)
## Informasi tambahan
- Posisi: Mahasiswa Teknologi Informasi
- Hobi: ngoding, menggambar, membaca, menonton anime
